# LINK TO THE PROGRAMMING PLAN : https://docs.google.com/document/d/1N-U7uMd1P9Ag5RtAJrodDq-DSvFPyUtatrgQ6N0LC2s/edit?usp=sharing


import array as arr

def howmanytimes():
  howMany = int(input("How many people do you want to calculate:"))
  for x in range(howMany):
    menu() 

data_list1 = arr.array('f', [])
data_list2 = arr.array('f', [])

def findMaleBodyDensity():
  #get inputs and append to array 
  chestSkinfold = float(input("Enter chest skinfold (mm): "))
  data_list1.append(chestSkinfold)
  abdomenSkinfold = float(input("Enter abdomen skinfold (mm): "))
  data_list1.append(abdomenSkinfold)
  thighSkinfold = float(input("Enter thigh skinfold (mm): "))
  data_list1.append(thighSkinfold) 
  age = int(input("Enter your age in years: "))
  data_list1.append(age)
  waistCircumfrence = float(input("Enter your waist circumfrence in m: "))
  data_list1.append(waistCircumfrence)
  forearmCircumference = float(input("Enter your forearm circumference in m: "))
  data_list1.append(forearmCircumference)
  #get sum
  sumOfAllSkinfolds = sum(data_list1[0:3])
  BodyDensity = 1.0990750 - 0.0008209*(sumOfAllSkinfolds) + 0.0000026* (sumOfAllSkinfolds**2) - 0.0002017*(age) - 0.005675*(waistCircumfrence) + 0.018586*(forearmCircumference)
  data_list1.append(BodyDensity)
  bodyFat = (495 / BodyDensity) - 450
  data_list1.append(bodyFat)
  print(bodyFat)
  for x in data_list1[:]: 
        data_list1.pop(-1)
        x += 1
  if bodyFat <= 0:
    print("Oh, your body fat percentage calculations came out as a negative number or zero so you probably have done something wrong, so please make sure you put in the right numbers!")
 

def findFemaleBodyDensity():
  tricepsSkinfold = float(input("Enter triceps skinfold (mm): "))
  data_list2.append(tricepsSkinfold)
  thighSkinfold = float(input("Enter thigh skinfold (mm): "))
  data_list2.append(thighSkinfold)
  suprailiacSkinfold = float(input("Enter suprailiac skinfold (mm): "))
  data_list2.append(suprailiacSkinfold)
  age = int(input("Enter your age in years: "))
  data_list2.append(age)
  glutealCircumference = float(input("Enter your gluteal circumference in cm: "))
  data_list2.append(glutealCircumference)
  sumOfAllSkinfolds = sum(data_list1[0:3])

  BodyDensity = 1.1470292 - 0.0009376*(sumOfAllSkinfolds) + 0.0000030* (sumOfAllSkinfolds**2) - 0.0001156*(age) - 0.0005839*(glutealCircumference)
  
  bodyFat = (495 / BodyDensity) - 450
  data_list2.append(bodyFat)
  print(f"Your body fat is:{bodyFat}%")
  for y in data_list2[:]:
          data_list2.pop(-1)   
          y += 1
  if bodyFat <= 0:
    print("Oh, your body fat percentage calculations came out as a negative number or zero so you probably have done something wrong, so please make sure you put in the right numbers")
    


  
def menu():
    print("1. Find Male Body Density")
    print("2. Find Female Body Density")
    mode = input("Enter your choice: ")
    
    if mode == "1":
        findMaleBodyDensity()

    elif mode == "2":
        findFemaleBodyDensity()

    else:
      print("Not an available option")
      
howmanytimes()
